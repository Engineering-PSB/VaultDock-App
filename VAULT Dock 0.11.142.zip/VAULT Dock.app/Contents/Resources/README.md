# VAULT Dock

## Configuration Parameters

VAULT Dock's configuration is securely stored in macOS Keychain and can't be accessed via defauls values.
However, to help with the initial applicaiton configuration, it is possible to pre-set these values; 
they will be read on the app start, and their values will be transfered to Keychain. 

- `hasPerformedInitialConfiguration` - (boolean) controls the initial Settings screen appearance.
- `timeIntervalToUndock` - (seconds) Time interval to take an assigned iPad from the dock; it becomes unassigned after that interval again.
- `dockName` - VAULT Dock device name.
- `clientAPIURL` - Client's JAMF PRO MDM URL.
- `username` - API username.
- `password` - API password.

Set the values with `defaults write com.psbhq.Dock parameterName "Parameter Value"`, for example:

```bash
defaults write com.psbhq.Dock dockName "VAULT Dock"
```
