# VAULT Dock

## Initial Setup

This repository contains the source code for the macOS version of VAULT Dock, a companion application for VAULT dock stations.

You need the latest version of Xcode to develop and build the application.

The build process is automated using Xcode Cloud workflows described under the **"Git Flow & Xcode Cloud"** section below.

Use the `develop` branch to work on the latest development version of the application.

```sh
git clone git@github.com:Engineering-PSB/Magic-Dock.git -b develop
cd Magic-Dock/VaultDock
open VaultDock.xcodeproj
```

## Where to start

- **Dock/DockManager.swift** - main logic, manages communication with dock stations, MDM, card readers.
- **Dock/USBManager.swift** - USB management logic for VAULT Dock devices.
- **Model/Configuration.swift** - configuration parameters and defaults.
- **Model/DataModel.swift** - data model for for storing device information and logs.
- **Card Readers/HIDReader.swift** - MagTek card reader management logic.
- **Card Readers/MFAAPI.swift** - VAS Pass MagTek API.
- **Card Readers/KeyboardReader.swift** - keyboard card reader management logic (disabled by default).
- **Updates/UpdateManager.swift** - update management logic for direct distribution.
- __Views/*__ - application views.

## Configuration Parameters

VAULT Dock's configuration is primarily managed via macOS Keychain for security, but certain parameters can be preset using defaults so that they take effect on the next application launch. Any username and password you set via defaults will be transferred to the Keychain automatically.

To set a parameter, use:
defaults write com.psbhq.Dock parameterName "Parameter Value"
For example:
defaults write com.psbhq.Dock dockName "VAULT Dock"

Below is a list of recognized parameters and their intended use. Unless stated otherwise, string parameters should be set via defaults write ... -string "Value", booleans via -bool, and numeric values (time intervals, integers) via -int or -float.

- **hasPerformedInitialConfiguration** (boolean)
  - Indicates whether the initial setup has run.
  - When false, the application automatically presents the configuration screen on first launch.

- **dockName** (string)
  - The display name for the VAULT Dock.
  - Default (if not set): The Mac’s local hostname.

- **minimalDockTime** (seconds)
  - The minimal time a device must remain in the dock before being assigned to a user.
  - Default: 10 seconds.

- **timeIntervalToUndock** (seconds)
  - After a device is assigned, if it is undocked (removed) longer than this interval, it becomes unassigned.
  - Default: 60 seconds.

- **cardReaderTimeIntervalBetweenKeyboardEvents** (seconds)
  - The maximum pause between keystrokes for keyboard-emulating card readers (such as badge readers).
  - Default: 1 second.

- **deviceDeactivationTimeInterval** (seconds)
  - Time-out interval for devices that are not found in Jamf (they get deactivated if they exceed this interval).
  - Default: 60 seconds.

- **deviceAPICallsDelayTimeInterval** (seconds)
  - Delay between consecutive Jamf API calls for a single device.
  - Default: 10 seconds.

- **userDatabaseUpdateTimeInterval** (seconds)
  - Frequency at which the internal user database is refreshed from a CSV file (if configured).
  - Default: 60 seconds.
  - Note: Only available in non-sandboxed builds.

- **updatesFetchingTimeInterval** (seconds)
  - Time interval for checking for application updates.
  - Default: 300 seconds (5 minutes).
  - Note: Only available in non-sandboxed builds.

- **timeIntervalToRearmAfterSoundNotification** (seconds)
  - After a sound notification (success/failure tone), how long to wait before re-enabling card reading.
  - Default: 5 seconds.

- **pickUpScenario** (integer)
  - Determines how devices are assigned vs. physically picked up.
  - 0 = "Assign then pick up" (default), 1 = "Pick up then assign."

- **canPlaySoundNotifications** (boolean)
  - Allows the application to play sound notifications for various events.
  - Default: false.

- **canFetchLDAPUsers** (boolean)
  - Enables fetching user information from an LDAP server via Jamf.
  - Default: false.

- **LDAPServerIdentifier** (string)
  - The Jamf-defined identifier for the LDAP server used when canFetchLDAPUsers is enabled.
  - Default: "" (empty).

- **canInstallBetaUpdates** (boolean)
  - Enables checking for and installing beta versions of updates.
  - Default: false.

- **isAutomaticUpdatesEnabled** (boolean)
  - Allows the application to automatically install new updates.
  - Default: false.

- **enableKeybordEmulatingCardReaders** (boolean)
  - Allows the app to accept input from keyboard-emulating card readers.
  - When enabled, cardReaderTimeIntervalBetweenKeyboardEvents is used.
  - Default: false.

- **showHIDTab** (boolean)
  - Enables or hides an internal diagnostics tab for HID devices.
  - Default: false.

- **clientAPIURL** (string)
  - The Jamf PRO MDM server URL.
  - Transferred to Keychain at launch if also providing username and password.

Set the values with `defaults write com.psbhq.Dock parameterName "Parameter Value"`, for example:

```bash
defaults write com.psbhq.Dock dockName "VAULT Dock"
```


## Git Flow & Xcode Cloud

This project follows the Git Flow methodology for managing branches and releases:

- Feature Branches
  - Each new feature or fix is implemented on a separate branch (for example, ""feature/cool-new-feature" or "bugfix/fix-some-issue").
  - When completed, it is merged into the develop branch via a pull request.

- Develop Branch
  - The `develop` branch contains the most recent code ready for internal testing.
  - Builds from `develop` are typically signed with a developer certificate and uploaded to TestFlight for internal distribution.

- Release Branches
  - When a feature set is complete and ready to be released, a release branch (for example, "release/1.0.0") is created from `develop`.
  - Critical fixes found during final testing may be applied on the release branch, and once validated, this branch merges into the `main` branch.

- Main Branch
  - The `main` branch contains production-ready code.

### Xcode Cloud CI Workflows

In Xcode Cloud, three workflows are configured to support this Git Flow:

1. **Manual Start**
   - This workflow can be triggered manually on any branch when you need a new test build.
   - It compiles the app, runs tests, and if successful, signs the build with a developer certificate.
   - The resulting artifact (binary) is then uploaded to TestFlight (for internal testing) and added to the develop branch of the VaultDock-App repository.

2. **TestFlight Build**
   - This workflow automatically triggers whenever the develop branch is updated (e.g., after merging in a feature branch).
   - It operates like "Manual Start," performing tests and signing the build with a developer certificate.
   - It then uploads the binary to TestFlight for internal testing.
   - No manual intervention is required once a pull request is merged into develop.

3. **Release Build**
   - This workflow starts when changes are pushed to any `release/` branch.
   - It prepares a build signed with a distribution certificate for external testing and/or final release.
   - Upon success, it merges or pushes the resulting release build to the main branch of the VaultDock-App repository.
   - From there, the build can be distributed via the App Store.

## LDAP server

LDAP test server is available at 104.236.56.187.

You can get all the information by running this command in Terminal:

```bash
ldapsearch -H ldap://104.236.56.187 -x -b dc=ldap,dc=psbhq,dc=com
```

The server provides phpLDAPadmin admin console for user management:

[http://104.236.56.187/phpldapadmin](http://104.236.56.187/phpldapadmin)

JAMF LDAP server connection is available at [https://pioneersquarenfr.jamfcloud.com/ldapServers.html?id=1&o=r](https://pioneersquarenfr.jamfcloud.com/ldapServers.html?id=1&o=r).

Please note that the Jamf LDAP server has a unique identifier, **id=1**, and that identifier should be used when configuring the application.

## LDAP Server User example

```sh
ldapsearch -H ldap://104.236.56.187 -x -b dc=ldap,dc=psbhq,dc=com
```

Response:
```
# extended LDIF
#
# LDAPv3
# base <dc=ldap,dc=psbhq,dc=com> with scope subtree
# filter: (objectclass=*)
# requesting: ALL
#

# ldap.psbhq.com
dn: dc=ldap,dc=psbhq,dc=com
objectClass: top
objectClass: dcObject
objectClass: organization
o: PSBHQ
dc: ldap

# people, ldap.psbhq.com
dn: ou=people,dc=ldap,dc=psbhq,dc=com
objectClass: organizationalUnit
ou: people

# User identifier, people, ldap.psbhq.com
dn: uid=<USER_IDENTIFIER>,ou=people,dc=ldap,dc=psbhq,dc=com
objectClass: inetOrgPerson
cn: <USER_FULL_NAME>
uid: <USER_IDENTIFIER>
sn: <USER_NAME>

# search result
search: 2
result: 0 Success

# numResponses: 4
# numEntries: 3
```

Where:
- **USER_IDENTIFIER** - the identifier that is added to the data section of NFC card
- **USER_NAME** - associated Jamf username string
- **USER_FULL_NAME** - full user name (name and surname, for example)

## Jamf Connection to the LDAP server

It is important to note the id of the created server, which is visible in the address line of your browser (e.g., `https://<account_id>.jamfcloud.com/ldapServers.html?`**`id=1`**`&o=r`)

Mappings page - Attribute Mappings:

- User ID - `sn`
- Username - `uid`

## Jamf LDAP API

`GET https://<account_id>.jamfcloud.com/JSSResource/ldapservers/id/<SERVER_ID>/user/<USER_UDENTIFIER>`

Where

- **SERVER_ID** - Jamf server id from the previous step
- **USER_IDENTIFIER** - `uid` value of the user in LDAP registry

If SERVER_ID is not found, the server returns 404 Not Found response.

If the provided `uid` is not found, the server returns 200 OK response with body:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<ldap_users>
    <size>0</size>
</ldap_users>
```

If the provided `uid` is found, the server returns 200 OK response with body:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<ldap_users>
    <size>1</size>
    <ldap_user>
        <uid>USER_IDENTIFIER</uid>
        <uuid/>
        <username>TestNFC123</username>
        <realname/>
        <real_name/>
        <email_address/>
        <phone/>
        <phone_number/>
        <building/>
        <department/>
        <room/>
        <position/>
    </ldap_user>
</ldap_users>
```
